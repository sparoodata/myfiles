#!/bin/bash

# Usage: ./db_compare.sh source_conn target_conn schemas
# Example: ./db_compare.sh "host=source.example.com port=5432 dbname=source_db user=source_user password=source_pass" \
#          "host=target.example.com port=5432 dbname=target_db user=target_user password=target_pass" \
#          "'public','myschema'"

SOURCE_CONN=$1
TARGET_CONN=$2
INCLUDE_SCHEMAS=$3  # e.g., "'public','myschema'"

# Dynamically get all .sql files in the current directory
SQL_FILES=()
for f in *.sql; do
    if [ -f "$f" ]; then
        SQL_FILES+=("$f")
    fi
done

# Check if any SQL files were found
if [ ${#SQL_FILES[@]} -eq 0 ]; then
    echo "No .sql files found in the current directory"
    exit 1
fi

# Create output directories if needed
mkdir -p source_outputs target_outputs

# Function to run a SQL file on a database and save output
run_sql() {
    local conn=$1
    local file=$2
    local output_dir=$3
    psql "$conn" -v include_schemas="$INCLUDE_SCHEMAS" -f "$file" > "$output_dir/$(basename "$file" .sql).txt" 2>&1
    if [ $? -ne 0 ]; then
        echo "Error executing $file with connection $conn"
        exit 1
    fi
}

# Run all SQL files on source and target servers
for file in "${SQL_FILES[@]}"; do
    echo "Executing $file on source server..."
    run_sql "$SOURCE_CONN" "$file" "source_outputs"
    echo "Executing $file on target server..."
    run_sql "$TARGET_CONN" "$file" "target_outputs"
done

# Compare outputs and prepare report
echo "=== Migration Comparison Report ==="
for file in "${SQL_FILES[@]}"; do
    base=$(basename "$file" .sql)
    source_file="source_outputs/$base.txt"
    target_file="target_outputs/$base.txt"
    diff_output=$(diff "$source_file" "$target_file")
    if [ -z "$diff_output" ]; then
        echo "$base: MATCH"
    else
        echo "$base: DIFFERENCE"
        echo "$diff_output"
        echo "----------------------------------------"
    fi
done