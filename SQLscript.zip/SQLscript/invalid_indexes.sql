SELECT n.nspname||'.'|| t.relname||'.'|| c.relname as index
FROM
  pg_index i
  JOIN pg_class c ON c.oid = i.indexrelid
  JOIN pg_class t ON t.oid = i.indrelid
  JOIN pg_namespace n ON n.oid = t.relnamespace
WHERE n.nspname in (:include_schemas)
  AND i.indisvalid = false
ORDER BY 1;