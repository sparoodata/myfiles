#!/bin/bash

TmpDir=/tmp
TmpFile=$TmpDir/psql.$$.out
SQLFile=get_table_rows.sql

## Functions

function fnUsage()
{

(
     echo -e "h) PGHOST"
     echo -e "d) PGDATABASE"
     echo -e "u) PGUSER"
     echo -e "p) PGPASSWORD"
     echo -e "P) PGPORT"
)

exit 2

}


# Ensure that we have a psql executable

PSQL=$(which psql 2>/dev/null)

if [[ $? -ne 0 ]]; then
        echo "ERROR: Unable to find the psql executable" >&2
        exit 1
fi

# Get the options

while getopts h:d:p:u:P: OPTION
do
     case $OPTION in
            h) PGHOST=$OPTARG;;
            d) PGDATABASE=$OPTARG;;
            u) PGUSER=$OPTARG ;;
            p) PGPASSWORD=$OPTARG ;;
            P) PGPORT=$OPTARG;;
            ?) echo "Unknown command line option. Exit" && fnUsage ;;
        esac
done

# Set some defaults

echo "Using host     -> ${PGHOST:=localhost}"
echo "Using Port     -> ${PGPORT:=5432}"
echo "Using User     -> ${PGUSER:=postgres}"
echo "Using Database -> ${PGDATABASE:=postgres}"

# Export the variables
export PGHOST
export PGPORT
export PGUSER
export PGDATABASE

export PGPASSWORD

# Build sql file
(
echo "SELECT table_schema || '.' ||table_name"
echo "FROM   information_schema.tables"
echo "WHERE  table_schema NOT IN ('pg_catalog',"
echo "                            'pglogical',"
echo "                            'information_schema',"
echo "                            'pg_toast' )"
echo " ORDER BY table_schema, table_name;"
) > $SQLFile

if [[ $? -ne 0 ]]; then
        echo "ERROR: Unable to create SQL file $SQLFile" >&2
        exit 1
fi

# Run the query
$PSQL -f ${SQLFile} -wt > $TmpFile

if [[ $? -ne 0 ]];then
        echo "ERROR: Unable to run SQL statement in psql" >&2
        exit 1
fi

if [[ -s $TmpFile ]]; then
        grep -si "error:" $TmpFile
        if [[ $? -eq 0 ]]; then
                echo "ERROR: Errors encountered running psql" >&2
                exit 1
        fi
else
        echo "ERROR: No output in output file" >&2
        exit 1
fi

MaxLen=0

# Get widest name
while read TabName
do
        TabLen=${#TabName}
        if [[ $TabLen -gt $MaxLen ]]
        then
                MaxLen=$TabLen
        fi
done < $TmpFile

# Add 1

((MaxLen++))

echo -e "\nCounting table rows ...\n"

RunTot=0

# Print the counts
while read TabName
do
        TabName=$(echo $TabName)
        if [[ ! -z $TabName ]]; then
                printf "%-${MaxLen}.${MaxLen}s : " $TabName

                Result=$($PSQL -c "SELECT COUNT(*) FROM ${TabName};" -t)

                if [[ $? -ne 0 ]]
                then
                        echo "ERROR: Unable to count table $TabName" >&2
                        exit 1
                fi

                Result=$(echo $Result)

                printf "%12d\n" $Result

                ((RunTot+=$Result))
        fi
done <$TmpFile

# Print out line
((LineLen=MaxLen+3+12))

printf "%0.s=" $(seq 1 $LineLen)

echo

# Print the total
printf "%-${MaxLen}.${MaxLen}s : %12d\n\n" "TOTAL ROWS" $RunTot

rm -f $TmpFile

exit 0

