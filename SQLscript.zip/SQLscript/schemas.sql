SELECT pg_catalog.pg_namespace.nspname::text as schema_size
FROM pg_catalog.pg_namespace
WHERE nspname IN (:include_schemas)
ORDER BY 1;