SELECT nsp.nspname||'.'|| cls.relname||'.'|| con.conname as constraint
FROM
  pg_constraint con
  JOIN pg_class cls ON cls.oid = con.conrelid
  JOIN pg_namespace nsp ON nsp.oid = cls.relnamespace
WHERE nsp.nspname in (:include_schemas)
  AND NOT con.convalidated                  -- constraint is NOT VALID
  AND con.conislocal                        -- constraint is enabled (not inherited)
  AND con.contype IN ('f','c','u','p','x')  -- relevant constraint types
ORDER BY 1;