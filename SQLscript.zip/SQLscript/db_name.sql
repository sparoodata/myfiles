select datname::text as db_name 
from pg_database where datname = current_database();