SELECT sequence_schema||'.'||sequence_name||'.'||data_type as sequence 
FROM information_schema.sequences 
where sequence_schema in (:include_schemas)
ORDER BY 1;