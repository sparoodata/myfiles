SELECT schemaname::text||'.'||viewname::text AS name
FROM pg_views
WHERE schemaname::text IN (:include_schemas)
 AND not (schemaname::text='public' and viewname::text='pg_stat_statements_info')
ORDER by 1;