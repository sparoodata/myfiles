select schemaname||'.'||matviewname as view_name
from pg_matviews
where schemaname in (:include_schemas)
order by 1;