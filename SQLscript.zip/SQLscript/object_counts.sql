WITH relevant_schemas AS (
    SELECT n.oid AS namespace_oid, n.nspname
    FROM pg_namespace n
    WHERE nspname IN (:include_schemas)
),
extension_func_oids AS (
    SELECT objid
    FROM pg_depend d
    JOIN pg_extension e ON d.refobjid = e.oid
    WHERE d.classid = 'pg_proc'::regclass
),
object_counts AS (
    SELECT 1 AS sort_order, 'Schema count' AS object_type, COUNT(*)::bigint AS object_count FROM relevant_schemas
    UNION ALL
    SELECT 2, 'Extension count', COUNT(*) FROM pg_extension
    UNION ALL
    SELECT 3, 'View count', COUNT(*) FROM pg_class c
        JOIN relevant_schemas s ON s.namespace_oid = c.relnamespace
        WHERE c.relkind = 'v'
        AND not (s.nspname='public' and c.relname='pg_stat_statements_info')
    UNION ALL
    SELECT 4, 'Table count', COUNT(*) FROM pg_class c
        JOIN relevant_schemas s ON s.namespace_oid = c.relnamespace
        WHERE c.relkind = 'r' AND NOT c.relispartition
        AND not (s.nspname='public' and c.relname='pg_stat_statements_info') 
    UNION ALL
    SELECT 16, 'Column count', COUNT(*)
    FROM  INFORMATION_SCHEMA.Columns
        JOIN relevant_schemas s ON s.nspname = table_schema
        AND not (s.nspname='public' and table_name='pg_stat_statements_info')
    UNION ALL
    SELECT 5, 'Materialized View count', COUNT(*) FROM pg_class c
        JOIN relevant_schemas s ON s.namespace_oid = c.relnamespace
        WHERE c.relkind = 'm'
    UNION ALL
    SELECT 6, 'Index count', COUNT(*) FROM pg_class c
        JOIN relevant_schemas s ON s.namespace_oid = c.relnamespace
        WHERE c.relkind = 'i'
    UNION ALL
    SELECT 8, 'Partition count', COUNT(*) FROM pg_inherits i
        JOIN pg_class c ON c.oid = i.inhparent
        JOIN relevant_schemas s ON s.namespace_oid = c.relnamespace
    UNION ALL
    SELECT 9, 'Trigger count', COUNT(*) FROM pg_trigger t
        JOIN pg_class c ON c.oid = t.tgrelid
        JOIN relevant_schemas s ON s.namespace_oid = c.relnamespace
        WHERE NOT t.tgisinternal
    UNION ALL
    SELECT 10, 'Sequence count', COUNT(*) FROM pg_class c
        JOIN relevant_schemas s ON s.namespace_oid = c.relnamespace
        WHERE c.relkind = 'S'
    UNION ALL
    SELECT 11, 'Primary Key count', COUNT(*) FROM pg_constraint con
        JOIN relevant_schemas s ON s.namespace_oid = con.connamespace
        WHERE con.contype = 'p'
    UNION ALL
    SELECT 12, 'Foreign Key count', COUNT(*) FROM pg_constraint con
        JOIN relevant_schemas s ON s.namespace_oid = con.connamespace
        WHERE con.contype = 'f'
    UNION ALL
    SELECT 13, 'Unique Constraint count', COUNT(*) FROM pg_constraint con
        JOIN relevant_schemas s ON s.namespace_oid = con.connamespace
        WHERE con.contype = 'u'
    UNION ALL
    SELECT 14, 'Check Constraint count', COUNT(*) FROM pg_constraint con
        JOIN relevant_schemas s ON s.namespace_oid = con.connamespace
        WHERE con.contype = 'c'
    UNION ALL
    SELECT 15, 'Userdefined Function count', COUNT(*) 
        FROM pg_proc p
        JOIN relevant_schemas s ON s.namespace_oid = p.pronamespace
        LEFT JOIN extension_func_oids ext ON ext.objid = p.oid
        WHERE p.prokind = 'f'
        AND ext.objid IS NULL
    UNION ALL
    SELECT 16, 'Invalid Constraint count', COUNT(*) FROM pg_constraint con
        JOIN relevant_schemas s ON s.namespace_oid = con.connamespace
        WHERE
          NOT con.convalidated                      -- constraint is NOT VALID
          AND con.conislocal                        -- constraint is enabled (not inherited)
          AND con.contype IN ('f','c','u','p','x')  -- relevant constraint types
    UNION ALL
    SELECT 17, 'Invalid Index count', COUNT(*) FROM   pg_index i
        JOIN pg_class c ON c.oid = i.indexrelid
        JOIN pg_class t ON t.oid = i.indrelid
        JOIN relevant_schemas s ON s.namespace_oid = c.relnamespace
        WHERE i.indisvalid = false
)
SELECT RPAD(object_type, 30, ' ')::text||' → '::text as object_type, LPAD(object_count::text, 4, ' ') as object_count
FROM object_counts
ORDER BY sort_order;