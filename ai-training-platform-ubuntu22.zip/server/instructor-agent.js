/**
 * Instructor Agent
 *
 * One per session. Plans a lesson on the fly from the topic, executes demos
 * inside the student's Linux user session, handles voice Q&A.
 *
 * Phase 1: Generate lesson outline (5-8 sections)
 * Phase 2: For each section: speak the explanation, then run the demo,
 *          then pause for questions, then move on.
 *
 * Voice flow:
 *   - Agent speaks → TTS → audio to browser
 *   - Student speaks → STT → text → agent classifies (question vs continue)
 *     → either answers and resumes OR proceeds
 */
const { spawn, execSync } = require('child_process');
const { chatWithGemma, synthesizeSpeech } = require('./voice-pipeline');

const LESSON_PLAN_PROMPT = `You are creating a hands-on training lesson for a student on a shared Ubuntu desktop.
Generate a structured lesson outline as JSON. The student will see your demos run live on screen.

Return ONLY this JSON shape (no markdown fences):
{
  "title": "Course title",
  "intro": "1-2 sentence intro the instructor speaks at the start",
  "sections": [
    {
      "id": 1,
      "title": "Section title",
      "narration": "What the instructor says before the demo (2-4 sentences, conversational)",
      "demo_steps": [
        { "type": "command", "cmd": "shell command", "explain": "what this does" },
        { "type": "open_url", "url": "https://...", "explain": "why we visit this" },
        { "type": "write_file", "path": "/tmp/foo.yml", "content": "...", "explain": "what we're creating" },
        { "type": "wait", "seconds": 3, "explain": "letting it process" }
      ],
      "summary": "1-2 sentence wrap-up the instructor speaks after the demo"
    }
  ],
  "outro": "Closing remarks (1-2 sentences)"
}

Rules:
- 4-6 sections total
- Each section has 2-5 demo steps
- Use realistic, working shell commands for Ubuntu 22.04
- Keep narration conversational like a teacher: "Now let's see what happens when..."
- Demos should build on each other`;

class InstructorAgent {
  constructor(session, broadcastFn) {
    this.session   = session;
    this.broadcast = broadcastFn;     // sends WS messages to all voice clients of this session
    this.aborted   = false;
    this.lesson    = null;
    this.currentSection = 0;
    this.history   = [];              // chat history for Q&A
    this.paused    = false;
    this.pauseResolve = null;
  }

  send(type, payload = {}) {
    this.broadcast(this.session.id, { type, ...payload });
  }

  // ── Speak: synthesize TTS and stream to browser ──
  async speak(text) {
    if (!text?.trim() || this.aborted) return;
    this.send('subtitle', { text });
    try {
      const wav = await synthesizeSpeech(text, this.session.id);
      if (wav && !this.aborted) {
        this.send('tts_audio', { audio: wav.toString('base64') });
        // Estimate duration: roughly 150 wpm → 0.4s/word
        const words = text.split(/\s+/).length;
        await sleep(Math.min(words * 350, 8000));
      }
    } catch (e) {
      console.error('[agent] speak error:', e.message);
    }
  }

  // ── Run a shell command in the student's session ──
  async runInSession(cmd) {
    this.send('terminal_cmd', { cmd });
    return new Promise(resolve => {
      const child = spawn('sudo', [
        '-u', this.session.username,
        '-H',
        'env',
        `DISPLAY=${this.session.display}`,
        `HOME=/home/${this.session.username}`,
        `USER=${this.session.username}`,
        'bash', '-c', cmd
      ]);
      let stdout = '', stderr = '';
      child.stdout.on('data', d => {
        const s = d.toString();
        stdout += s;
        this.send('terminal_output', { data: s, stream: 'stdout' });
      });
      child.stderr.on('data', d => {
        const s = d.toString();
        stderr += s;
        this.send('terminal_output', { data: s, stream: 'stderr' });
      });
      child.on('close', code => {
        this.send('terminal_done', { exitCode: code });
        resolve({ stdout, stderr, exitCode: code });
      });
      // Safety timeout
      setTimeout(() => { try { child.kill('SIGKILL'); } catch {} resolve({ stdout, stderr, exitCode: -1 }); }, 60_000);
    });
  }

  async openUrlInSession(url) {
    return this.runInSession(`xdg-open "${url}" >/dev/null 2>&1 &`);
  }

  async writeFileInSession(filepath, content) {
    // Write via tee under sudo as the user
    const b64 = Buffer.from(content).toString('base64');
    return this.runInSession(`mkdir -p $(dirname "${filepath}") && echo "${b64}" | base64 -d > "${filepath}"`);
  }

  // ── Plan generation ──
  async generatePlan(topic) {
    this.send('agent_status', { status: 'planning', topic });
    const reply = await chatWithGemma([
      { role: 'system', content: LESSON_PLAN_PROMPT },
      { role: 'user',   content: `Topic: ${topic}` }
    ], { num_predict: 2000, temperature: 0.5 });

    try {
      const cleaned = reply.replace(/```json|```/g, '').trim();
      this.lesson = JSON.parse(cleaned);
    } catch (e) {
      throw new Error(`Could not parse lesson plan: ${e.message}\nRaw: ${reply.slice(0, 200)}`);
    }
    this.send('lesson_ready', { lesson: this.lesson });
    return this.lesson;
  }

  // ── Main teach loop ──
  async teach(topic) {
    try {
      await this.generatePlan(topic);
      if (this.aborted) return;

      // Intro
      await this.speak(`Welcome! Today we're going to learn about ${this.lesson.title}.`);
      await this.speak(this.lesson.intro);

      // Sections
      for (let i = 0; i < this.lesson.sections.length; i++) {
        if (this.aborted) return;
        this.currentSection = i;
        const section = this.lesson.sections[i];
        this.send('section_start', { index: i, total: this.lesson.sections.length, title: section.title });

        await this.speak(`Section ${i + 1}: ${section.title}.`);
        await this.checkPaused();
        await this.speak(section.narration);
        await this.checkPaused();

        // Run demo steps
        for (const step of section.demo_steps || []) {
          if (this.aborted) return;
          await this.checkPaused();
          await this.executeStep(step);
        }
        await this.checkPaused();

        await this.speak(section.summary);
        await sleep(1500);
        // Implicit pause for questions before moving on
        this.send('section_pause', { question_window: 3 });
        await sleep(3000);
      }

      // Outro
      if (!this.aborted) {
        await this.speak(this.lesson.outro);
        await this.speak('That concludes our session. You can ask me any questions about what we covered.');
        this.send('agent_status', { status: 'finished' });
      }
    } catch (e) {
      console.error('[agent] teach error:', e);
      this.send('agent_status', { status: 'error', error: e.message });
    }
  }

  async executeStep(step) {
    this.send('demo_step', { step });
    if (step.explain) await this.speak(step.explain);

    switch (step.type) {
      case 'command':
        await this.runInSession(step.cmd);
        break;
      case 'open_url':
        await this.openUrlInSession(step.url);
        await sleep(2500); // give browser time to load
        break;
      case 'write_file':
        await this.writeFileInSession(step.path, step.content || '');
        break;
      case 'wait':
        await sleep((step.seconds || 1) * 1000);
        break;
    }
  }

  // ── Pause/resume for questions ──
  pause() {
    if (!this.paused) {
      this.paused = true;
      this.send('agent_status', { status: 'paused' });
    }
  }

  resume() {
    if (this.paused && this.pauseResolve) {
      this.pauseResolve();
      this.pauseResolve = null;
      this.paused = false;
      this.send('agent_status', { status: 'resumed' });
    }
  }

  async checkPaused() {
    if (this.paused) {
      await new Promise(resolve => { this.pauseResolve = resolve; });
    }
  }

  // ── Q&A: student asked something via voice ──
  async handleStudentQuestion(text) {
    if (!text?.trim()) return;
    this.send('student_said', { text });

    // Pause the lesson while we answer
    this.pause();

    const context = this.lesson
      ? `You are teaching: "${this.lesson.title}". Currently on section ${this.currentSection + 1}: "${this.lesson.sections[this.currentSection]?.title}".`
      : 'No lesson active yet.';

    this.history.push({ role: 'user', content: text });

    const messages = [
      {
        role: 'system',
        content: `You are a friendly DevOps instructor running a live training session.
${context}
Answer the student's question conversationally in 2-4 sentences. Be encouraging.
After answering, the lesson will resume automatically.`
      },
      ...this.history.slice(-6)
    ];

    try {
      const reply = await chatWithGemma(messages, { num_predict: 250, temperature: 0.6 });
      this.history.push({ role: 'assistant', content: reply });
      await this.speak(reply);
    } catch (e) {
      await this.speak(`Sorry, I had trouble with that. Let me know if you want to ask again.`);
    }

    // Resume the lesson
    setTimeout(() => this.resume(), 500);
  }

  abort() {
    this.aborted = true;
    if (this.pauseResolve) { this.pauseResolve(); this.pauseResolve = null; }
    this.send('agent_status', { status: 'stopped' });
  }
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

module.exports = { InstructorAgent };
