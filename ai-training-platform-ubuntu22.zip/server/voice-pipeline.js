/**
 * Voice Pipeline
 * Mic audio (browser) → Whisper STT → Gemma 4 (instructor agent) → Piper TTS → Audio out (browser)
 *
 * Each session has its own conversation state with the LLM.
 * Audio chunks come over WebSocket as Float32 / Int16 PCM and we accumulate
 * until silence is detected, then transcribe.
 */
const fs   = require('fs').promises;
const path = require('path');
const { execFile, spawn } = require('child_process');
const { promisify } = require('util');
const execFileAsync = promisify(execFile);

const WHISPER_URL  = process.env.WHISPER_URL  || 'http://localhost:8080/inference';
const PIPER_BIN    = process.env.PIPER_BIN    || 'piper';
const PIPER_VOICE  = process.env.PIPER_VOICE  || '/opt/piper/voices/en_US-amy-medium.onnx';
const OLLAMA_HOST  = process.env.OLLAMA_HOST  || 'http://localhost:11434';
const OLLAMA_MODEL = process.env.OLLAMA_MODEL || 'gemma4:e4b';

const TMP_DIR = '/tmp/training-platform';
fs.mkdir(TMP_DIR, { recursive: true }).catch(() => {});

// ── STT: Whisper.cpp HTTP server ──────────────────────────────────────────────
async function transcribeAudio(wavBuffer) {
  const form = new FormData();
  form.append('file', new Blob([wavBuffer], { type: 'audio/wav' }), 'audio.wav');
  form.append('temperature', '0');
  form.append('response_format', 'json');
  // Whisper.cpp's server.cpp accepts these fields

  try {
    const r = await fetch(WHISPER_URL, { method: 'POST', body: form });
    if (!r.ok) throw new Error(`Whisper HTTP ${r.status}`);
    const data = await r.json();
    return (data.text || '').trim();
  } catch (e) {
    console.error('[stt] error:', e.message);
    return '';
  }
}

// ── TTS: Piper ────────────────────────────────────────────────────────────────
async function synthesizeSpeech(text, sessionId) {
  if (!text?.trim()) return null;
  const outFile = path.join(TMP_DIR, `tts_${sessionId}_${Date.now()}.wav`);

  return new Promise((resolve, reject) => {
    const piper = spawn(PIPER_BIN, [
      '--model',         PIPER_VOICE,
      '--output_file',   outFile
    ]);
    piper.stdin.write(text);
    piper.stdin.end();

    let stderr = '';
    piper.stderr.on('data', d => stderr += d.toString());

    piper.on('close', async code => {
      if (code !== 0) {
        console.error('[tts] piper failed:', stderr);
        return resolve(null);
      }
      try {
        const buf = await fs.readFile(outFile);
        await fs.unlink(outFile).catch(() => {});
        resolve(buf);
      } catch (e) { resolve(null); }
    });
    piper.on('error', e => {
      console.error('[tts] spawn error:', e.message);
      resolve(null);
    });
  });
}

// ── LLM: Gemma 4 via Ollama ───────────────────────────────────────────────────
async function chatWithGemma(messages, options = {}) {
  const r = await fetch(`${OLLAMA_HOST}/api/chat`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      model:    OLLAMA_MODEL,
      messages,
      stream:   false,
      options: {
        temperature: options.temperature ?? 0.4,
        num_predict: options.num_predict ?? 400,
        num_ctx:     options.num_ctx ?? 16384
      }
    })
  });
  if (!r.ok) throw new Error(`Ollama HTTP ${r.status}: ${await r.text()}`);
  const data = await r.json();
  return data.message?.content || '';
}

// ── Streaming chat (token-by-token for fast TTS start) ────────────────────────
async function* streamChat(messages, options = {}) {
  const r = await fetch(`${OLLAMA_HOST}/api/chat`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      model:    OLLAMA_MODEL,
      messages,
      stream:   true,
      options: {
        temperature: options.temperature ?? 0.4,
        num_predict: options.num_predict ?? 400
      }
    })
  });

  const reader  = r.body.getReader();
  const decoder = new TextDecoder();
  let buf = '';

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += decoder.decode(value, { stream: true });
    const lines = buf.split('\n');
    buf = lines.pop() || '';
    for (const line of lines) {
      if (!line.trim()) continue;
      try {
        const obj = JSON.parse(line);
        const tok = obj.message?.content;
        if (tok) yield tok;
      } catch {}
    }
  }
}

// ── Health check ──────────────────────────────────────────────────────────────
async function healthCheck() {
  const status = { ollama: false, whisper: false, piper: false };
  // Ollama
  try {
    const r = await fetch(`${OLLAMA_HOST}/api/tags`);
    const d = await r.json();
    status.ollama = (d.models || []).some(m => m.name.includes(OLLAMA_MODEL.split(':')[0]));
    status.ollamaModels = (d.models || []).map(m => m.name);
  } catch (e) { status.ollamaError = e.message; }

  // Whisper
  try {
    const r = await fetch(WHISPER_URL.replace('/inference', '/'), { method: 'GET' });
    status.whisper = r.ok || r.status === 404; // server is up even if endpoint mismatches
  } catch (e) { status.whisperError = e.message; }

  // Piper
  try {
    await execFileAsync(PIPER_BIN, ['--help'], { timeout: 2000 });
    status.piper = true;
  } catch (e) { status.piperError = e.message; }

  return status;
}

module.exports = {
  transcribeAudio,
  synthesizeSpeech,
  chatWithGemma,
  streamChat,
  healthCheck
};
