require('dotenv').config();
const express  = require('express');
const http     = require('http');
const path     = require('path');
const httpProxy = require('http-proxy');
const { WebSocketServer } = require('ws');

const sm     = require('./session-manager');
const voice  = require('./voice-pipeline');
const { InstructorAgent } = require('./instructor-agent');

const PORT = process.env.PORT || 3000;

const app    = express();
const server = http.createServer(app);
app.use(express.json({ limit: '10mb' }));
app.use(express.static(path.join(__dirname, '..', 'public')));

// ── Per-session WebSocket clients ─────────────────────────────────────────────
const sessionClients = new Map();   // sessionId → Set<WebSocket>

function broadcastToSession(sessionId, msg) {
  const set = sessionClients.get(sessionId);
  if (!set) return;
  const raw = JSON.stringify(msg);
  for (const ws of set) {
    if (ws.readyState === 1) ws.send(raw);
  }
}

// ── REST API ──────────────────────────────────────────────────────────────────
app.get('/api/health', async (req, res) => {
  const v = await voice.healthCheck();
  res.json({ ...v, sessions: sm.listSessions().length, maxSessions: parseInt(process.env.MAX_SESSIONS) || 10 });
});

app.post('/api/session/start', async (req, res) => {
  const { topic } = req.body;
  if (!topic?.trim()) return res.status(400).json({ error: 'topic required' });

  try {
    const session = await sm.createSession(topic);
    res.json(session);

    // Kick off the instructor agent in the background
    setTimeout(async () => {
      const sess = sm.getSession(session.sessionId);
      if (!sess) return;
      const agent = new InstructorAgent(sess, broadcastToSession);
      sess.instructorAgent = agent;
      try {
        await agent.teach(topic);
      } catch (e) {
        broadcastToSession(session.sessionId, { type: 'agent_status', status: 'error', error: e.message });
      }
    }, 500);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.post('/api/session/:id/stop', (req, res) => {
  sm.destroySession(req.params.id);
  res.json({ ok: true });
});

app.get('/api/sessions', (req, res) => {
  res.json(sm.listSessions());
});

// ── noVNC proxy: /vnc/{sessionId}/* → localhost:novncPort ─────────────────────
const proxy = httpProxy.createProxyServer({ ws: true, changeOrigin: true });
proxy.on('error', (err, req, res) => {
  console.error('[proxy] error:', err.message);
  if (res?.writeHead) { res.writeHead(502); res.end('Proxy error: ' + err.message); }
});

app.use('/vnc/:sessionId', (req, res, next) => {
  const sess = sm.getSession(req.params.sessionId);
  if (!sess) return res.status(404).send('Session not found');
  sm.touchSession(req.params.sessionId);
  // Strip the /vnc/{sessionId} prefix
  req.url = req.url || '/';
  proxy.web(req, res, { target: `http://localhost:${sess.novncPort}` });
});

// Handle WebSocket upgrades for noVNC (websockify)
server.on('upgrade', (req, socket, head) => {
  const url = req.url || '';
  // Voice channel: /voice/{sessionId}
  const voiceMatch = url.match(/^\/voice\/([^/?]+)/);
  if (voiceMatch) {
    voiceWss.handleUpgrade(req, socket, head, ws => {
      ws.sessionId = voiceMatch[1];
      voiceWss.emit('connection', ws, req);
    });
    return;
  }
  // VNC websocket: /vnc/{sessionId}/websockify
  const vncMatch = url.match(/^\/vnc\/([^/]+)\/(.*)/);
  if (vncMatch) {
    const sess = sm.getSession(vncMatch[1]);
    if (!sess) { socket.destroy(); return; }
    req.url = '/' + vncMatch[2];
    proxy.ws(req, socket, head, { target: `http://localhost:${sess.novncPort}` });
    return;
  }
  socket.destroy();
});

// ── Voice WebSocket: bidirectional audio + control ────────────────────────────
const voiceWss = new WebSocketServer({ noServer: true });

voiceWss.on('connection', (ws, req) => {
  const sessionId = ws.sessionId;
  const sess = sm.getSession(sessionId);
  if (!sess) { ws.close(); return; }

  // Register client for broadcast
  if (!sessionClients.has(sessionId)) sessionClients.set(sessionId, new Set());
  sessionClients.get(sessionId).add(ws);
  sess.voiceClients.add(ws);
  sm.touchSession(sessionId);

  ws.send(JSON.stringify({ type: 'voice_connected', sessionId, topic: sess.topic }));

  // Per-connection audio buffer (we accumulate until VAD says stop)
  let audioChunks = [];
  let speaking = false;
  let silenceTimer = null;
  const SILENCE_MS = 800;

  ws.on('message', async (raw, isBinary) => {
    sm.touchSession(sessionId);

    if (isBinary) {
      // PCM audio chunk from the browser
      audioChunks.push(Buffer.from(raw));
      if (!speaking) speaking = true;
      // Reset silence timer
      if (silenceTimer) clearTimeout(silenceTimer);
      silenceTimer = setTimeout(async () => {
        if (audioChunks.length === 0) return;
        const wav = pcmChunksToWav(audioChunks, 16000);
        audioChunks = [];
        speaking = false;
        // Transcribe
        ws.send(JSON.stringify({ type: 'transcribing' }));
        const text = await voice.transcribeAudio(wav);
        if (text && text.length > 2) {
          // Send to instructor agent
          if (sess.instructorAgent) {
            sess.instructorAgent.handleStudentQuestion(text);
          } else {
            ws.send(JSON.stringify({ type: 'no_agent', text }));
          }
        }
      }, SILENCE_MS);
      return;
    }

    // JSON control message
    let msg;
    try { msg = JSON.parse(raw.toString()); } catch { return; }

    if (msg.type === 'pause' && sess.instructorAgent) sess.instructorAgent.pause();
    if (msg.type === 'resume' && sess.instructorAgent) sess.instructorAgent.resume();
    if (msg.type === 'stop')   sm.destroySession(sessionId);
    if (msg.type === 'text_question' && sess.instructorAgent) {
      sess.instructorAgent.handleStudentQuestion(msg.text);
    }
  });

  ws.on('close', () => {
    sessionClients.get(sessionId)?.delete(ws);
    sess.voiceClients.delete(ws);
  });
});

// ── Helper: wrap raw 16kHz PCM Int16 into a WAV buffer ───────────────────────
function pcmChunksToWav(chunks, sampleRate = 16000) {
  const pcm = Buffer.concat(chunks);
  const dataSize = pcm.length;
  const header = Buffer.alloc(44);
  header.write('RIFF', 0);
  header.writeUInt32LE(36 + dataSize, 4);
  header.write('WAVE', 8);
  header.write('fmt ', 12);
  header.writeUInt32LE(16, 16);
  header.writeUInt16LE(1, 20);
  header.writeUInt16LE(1, 22);
  header.writeUInt32LE(sampleRate, 24);
  header.writeUInt32LE(sampleRate * 2, 28);
  header.writeUInt16LE(2, 32);
  header.writeUInt16LE(16, 34);
  header.write('data', 36);
  header.writeUInt32LE(dataSize, 40);
  return Buffer.concat([header, pcm]);
}

server.listen(PORT, () => {
  console.log(`
╔════════════════════════════════════════════════╗
║   🎓 AI Training Platform                      ║
║   Multi-session, voice-driven, browser-native  ║
╚════════════════════════════════════════════════╝
  Port      : ${PORT}
  Ollama    : ${process.env.OLLAMA_HOST || 'http://localhost:11434'}
  Whisper   : ${process.env.WHISPER_URL || 'http://localhost:8080/inference'}
  Piper     : ${process.env.PIPER_BIN || 'piper'}
  Max users : ${process.env.MAX_SESSIONS || 10}

  Open http://localhost:${PORT} in a browser.
`);
});
