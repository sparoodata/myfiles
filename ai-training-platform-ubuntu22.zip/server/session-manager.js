/**
 * Session Manager
 * Each student gets a dedicated Linux user with their own X display, VNC, and instructor agent.
 *
 * Per-session resources:
 *   - Linux user: trainee-{id}
 *   - X display:  :{10 + slot}
 *   - VNC port:   5910 + slot
 *   - noVNC port: 6080 + slot
 *   - Voice WS:   inherited from main server
 *
 * Slots are recycled when sessions end.
 */
const { spawn, execSync } = require('child_process');
const fs   = require('fs').promises;
const path = require('path');
const os   = require('os');

const MAX_SESSIONS    = parseInt(process.env.MAX_SESSIONS) || 10;
const DISPLAY_BASE    = 10;
const VNC_PORT_BASE   = 5910;
const NOVNC_PORT_BASE = 6080;
const SCREEN_RES      = process.env.SCREEN_RES || '1280x800x24';
const SESSION_TIMEOUT = 60 * 60 * 1000; // 1 hour idle

// ── State ─────────────────────────────────────────────────────────────────────
const sessions = new Map();     // sessionId → session object
const slotsUsed = new Set();    // which slot numbers are in use

function nextSlot() {
  for (let i = 0; i < MAX_SESSIONS; i++) {
    if (!slotsUsed.has(i)) { slotsUsed.add(i); return i; }
  }
  return null;
}

// ── User management ──────────────────────────────────────────────────────────
async function ensureUser(username) {
  try {
    execSync(`id ${username}`, { stdio: 'ignore' });
    return false; // exists
  } catch {
    // Create user
    execSync(`sudo useradd -m -s /bin/bash ${username}`);
    // Add to common groups for desktop work
    execSync(`sudo usermod -aG sudo,docker,audio,video ${username} 2>/dev/null || true`);
    // Random password (we never expose this — sessions auth via the orchestrator)
    const pw = require('crypto').randomBytes(12).toString('hex');
    execSync(`echo "${username}:${pw}" | sudo chpasswd`);
    return true;
  }
}

async function deleteUser(username) {
  try {
    execSync(`sudo pkill -KILL -u ${username} 2>/dev/null || true`);
    await new Promise(r => setTimeout(r, 1000));
    execSync(`sudo userdel -r ${username} 2>/dev/null || true`);
  } catch (e) { /* silent */ }
}

// ── Process helpers ───────────────────────────────────────────────────────────
function spawnAsUser(username, cmd, args, opts = {}) {
  // Use sudo to run a command as another user
  const fullArgs = ['-u', username, '-H', '--', cmd, ...args];
  return spawn('sudo', fullArgs, {
    stdio:  opts.stdio || ['ignore', 'pipe', 'pipe'],
    env:    { ...process.env, ...(opts.env || {}) },
    detached: opts.detached || false
  });
}

// ── Session lifecycle ─────────────────────────────────────────────────────────
async function createSession(topic) {
  const slot = nextSlot();
  if (slot === null) throw new Error('All session slots are full');

  const sessionId = `s${Date.now()}_${slot}`;
  const username  = `trainee${slot}`;
  const display   = `:${DISPLAY_BASE + slot}`;
  const vncPort   = VNC_PORT_BASE + slot;
  const novncPort = NOVNC_PORT_BASE + slot;

  console.log(`[session ${sessionId}] starting — user=${username} display=${display} vnc=${vncPort} novnc=${novncPort}`);

  // 1. Make sure the OS user exists
  await ensureUser(username);

  // 2. Start Xvfb (virtual framebuffer X display)
  const xvfb = spawnAsUser(username, 'Xvfb', [
    display, '-screen', '0', SCREEN_RES, '-ac', '-noreset', '+extension', 'GLX'
  ], { detached: true });
  xvfb.unref();
  await sleep(800);

  // 3. Start XFCE desktop on that display
  const xfce = spawnAsUser(username, 'startxfce4', [], {
    env: { DISPLAY: display, HOME: `/home/${username}`, USER: username, XDG_RUNTIME_DIR: `/tmp/runtime-${username}` },
    detached: true
  });
  xfce.unref();
  await sleep(2500); // give the desktop time to come up

  // 4. Start x11vnc — exposes the X display as a VNC server
  const x11vnc = spawnAsUser(username, 'x11vnc', [
    '-display',     display,
    '-rfbport',     String(vncPort),
    '-forever',
    '-shared',
    '-nopw',
    '-localhost',
    '-quiet'
  ], { detached: true });
  x11vnc.unref();
  await sleep(700);

  // 5. Start noVNC — bridges WebSocket → VNC for the browser
  // websockify is part of noVNC. Adjust the path if needed.
  const websockify = spawn('websockify', [
    '--web', '/usr/share/novnc',
    String(novncPort),
    `localhost:${vncPort}`
  ], { detached: true, stdio: 'ignore' });
  websockify.unref();

  // 6. Build session object
  const session = {
    id:        sessionId,
    slot,
    username,
    display,
    vncPort,
    novncPort,
    topic,
    createdAt: Date.now(),
    lastActive: Date.now(),
    pids: [xvfb.pid, xfce.pid, x11vnc.pid, websockify.pid].filter(Boolean),
    instructorAgent: null,
    voiceClients: new Set()
  };
  sessions.set(sessionId, session);

  // 7. Auto-cleanup timer
  session.cleanupTimer = setInterval(() => {
    if (Date.now() - session.lastActive > SESSION_TIMEOUT) {
      console.log(`[session ${sessionId}] idle timeout`);
      destroySession(sessionId);
    }
  }, 60_000);

  return {
    sessionId,
    novncUrl: `/vnc/${sessionId}/`,                 // proxied below
    vncPort,
    novncPort,
    username,
    display,
    topic
  };
}

async function destroySession(sessionId) {
  const session = sessions.get(sessionId);
  if (!session) return;

  console.log(`[session ${sessionId}] destroying`);
  clearInterval(session.cleanupTimer);

  // Stop instructor agent first
  if (session.instructorAgent) {
    try { session.instructorAgent.abort(); } catch {}
  }

  // Kill all processes spawned for this session
  for (const pid of session.pids) {
    try { process.kill(pid, 'SIGTERM'); } catch {}
  }
  // Belt and suspenders: kill anything running as that user
  try { execSync(`sudo pkill -KILL -u ${session.username} 2>/dev/null || true`); } catch {}

  // Free the slot but keep the user (faster re-spawn next time)
  slotsUsed.delete(session.slot);
  sessions.delete(sessionId);
}

function getSession(sessionId) {
  return sessions.get(sessionId);
}

function listSessions() {
  return Array.from(sessions.values()).map(s => ({
    id: s.id, topic: s.topic, username: s.username,
    createdAt: s.createdAt, lastActive: s.lastActive
  }));
}

function touchSession(sessionId) {
  const s = sessions.get(sessionId);
  if (s) s.lastActive = Date.now();
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

// ── Cleanup on shutdown ───────────────────────────────────────────────────────
process.on('SIGINT',  () => { for (const id of sessions.keys()) destroySession(id); process.exit(0); });
process.on('SIGTERM', () => { for (const id of sessions.keys()) destroySession(id); process.exit(0); });

module.exports = {
  createSession, destroySession, getSession, listSessions, touchSession,
  spawnAsUser
};
