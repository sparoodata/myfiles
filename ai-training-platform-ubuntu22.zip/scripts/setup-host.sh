#!/bin/bash
# AI Training Platform — host setup for Ubuntu 22.04 (jammy)
# Idempotent: safe to re-run.
set -e

# ─── Output helpers ────────────────────────────────────────────────────────────
GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'; RED='\033[0;31m'; NC='\033[0m'
log()  { echo -e "${BLUE}▸${NC} $1"; }
ok()   { echo -e "${GREEN}✓${NC} $1"; }
warn() { echo -e "${YELLOW}⚠${NC} $1"; }
fail() { echo -e "${RED}✗${NC} $1"; exit 1; }

# ─── Sanity checks ────────────────────────────────────────────────────────────
[ "$EUID" -eq 0 ] && fail "Don't run as root. Use a regular user with sudo."
sudo -n true 2>/dev/null || sudo -v || fail "sudo authentication failed"

UBUNTU_VER=$(lsb_release -rs 2>/dev/null || echo "unknown")
if [ "$UBUNTU_VER" != "22.04" ]; then
  warn "This script is tuned for Ubuntu 22.04. You're on $UBUNTU_VER. Proceeding anyway..."
fi

echo "═══════════════════════════════════════════════════"
echo "  AI Training Platform — Host Setup (Ubuntu 22.04)"
echo "═══════════════════════════════════════════════════"
echo

# ─── 1. APT packages ──────────────────────────────────────────────────────────
log "Updating apt cache..."
sudo apt-get update -qq

log "Installing system packages..."
sudo DEBIAN_FRONTEND=noninteractive apt-get install -y \
  xvfb x11vnc novnc websockify \
  xfce4 xfce4-terminal dbus-x11 \
  firefox xdg-utils \
  curl wget jq git ca-certificates gnupg lsb-release \
  build-essential cmake pkg-config libssl-dev \
  ffmpeg \
  python3 python3-pip python3-venv

# Ubuntu 22 ships firefox as a snap by default. The snap version doesn't play nicely with Xvfb,
# so we install firefox-esr from the Mozilla PPA which gives us a real .deb binary.
if ! command -v firefox-esr >/dev/null 2>&1; then
  log "Installing firefox-esr (Xvfb-friendly, replaces snap)..."
  sudo add-apt-repository -y ppa:mozillateam/ppa 2>/dev/null || true
  # Pin the PPA above the snap transition package
  sudo tee /etc/apt/preferences.d/mozilla-firefox >/dev/null <<EOF
Package: *
Pin: release o=LP-PPA-mozillateam
Pin-Priority: 1001
EOF
  sudo apt-get update -qq
  sudo apt-get install -y firefox-esr || warn "firefox-esr install failed — snap firefox will be used as fallback"
fi
ok "System packages installed"

# ─── 2. Node.js 20 ────────────────────────────────────────────────────────────
NODE_OK=false
if command -v node >/dev/null && [ "$(node -v | sed 's/v//' | cut -d. -f1)" -ge 20 ]; then
  NODE_OK=true
fi

if ! $NODE_OK; then
  log "Installing Node.js 20 from NodeSource..."
  curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
  sudo apt-get install -y nodejs
fi
ok "Node $(node -v)"

# ─── 3. Ollama + Gemma 4 E4B ──────────────────────────────────────────────────
if ! command -v ollama >/dev/null; then
  log "Installing Ollama..."
  curl -fsSL https://ollama.com/install.sh | sh
fi
ok "Ollama installed: $(ollama --version 2>&1 | head -1)"

# Make sure the daemon is running
sudo systemctl enable ollama 2>/dev/null || true
sudo systemctl start ollama 2>/dev/null || (nohup ollama serve >/tmp/ollama.log 2>&1 &)
sleep 3

# Wait until Ollama is responding
for i in {1..15}; do
  curl -sf http://localhost:11434/api/tags >/dev/null 2>&1 && break
  [ $i -eq 15 ] && warn "Ollama did not respond after 15s — check 'systemctl status ollama'"
  sleep 1
done

GEMMA_MODEL="${GEMMA_MODEL:-gemma4:e4b}"
log "Ensuring $GEMMA_MODEL is pulled (≈9.6GB on first run)..."
if ollama list 2>/dev/null | grep -q "${GEMMA_MODEL%:*}"; then
  ok "$GEMMA_MODEL already present"
else
  ollama pull "$GEMMA_MODEL" || warn "Could not pull $GEMMA_MODEL — try manually: ollama pull $GEMMA_MODEL"
fi

# ─── 4. whisper.cpp ───────────────────────────────────────────────────────────
WHISPER_DIR="/opt/whisper.cpp"

if [ ! -d "$WHISPER_DIR" ]; then
  log "Cloning whisper.cpp..."
  sudo git clone --depth 1 https://github.com/ggerganov/whisper.cpp "$WHISPER_DIR"
fi

# Build with server target enabled
if [ ! -f "$WHISPER_DIR/build/bin/whisper-server" ] && [ ! -f "$WHISPER_DIR/build/bin/server" ]; then
  log "Building whisper.cpp with server (this takes 2-3 min)..."
  cd "$WHISPER_DIR"
  sudo cmake -B build -DGGML_NATIVE=ON -DWHISPER_BUILD_SERVER=ON >/dev/null
  sudo cmake --build build -j"$(nproc)" --config Release --target whisper-server 2>&1 | tail -3
  cd - >/dev/null
fi

# Locate the server binary (path moved between whisper.cpp versions)
WHISPER_SERVER=""
for p in "$WHISPER_DIR/build/bin/whisper-server" "$WHISPER_DIR/build/bin/server" "$WHISPER_DIR/server"; do
  [ -x "$p" ] && WHISPER_SERVER="$p" && break
done
[ -n "$WHISPER_SERVER" ] && ok "whisper-server: $WHISPER_SERVER" || warn "whisper-server binary not found"

# Download the base.en model (~150MB)
WHISPER_MODEL="$WHISPER_DIR/models/ggml-base.en.bin"
if [ ! -f "$WHISPER_MODEL" ]; then
  log "Downloading whisper base.en model (~150MB)..."
  sudo bash "$WHISPER_DIR/models/download-ggml-model.sh" base.en
fi
ok "Whisper model: $WHISPER_MODEL"

# ─── 5. Piper TTS ─────────────────────────────────────────────────────────────
PIPER_DIR="/opt/piper"
if ! command -v piper >/dev/null && [ ! -x "$PIPER_DIR/piper" ]; then
  log "Installing Piper TTS..."
  ARCH=$(uname -m)
  case "$ARCH" in
    x86_64)  PIPER_ARCH="amd64" ;;
    aarch64) PIPER_ARCH="arm64" ;;
    armv7l)  PIPER_ARCH="armv7" ;;
    *)       fail "Unsupported architecture: $ARCH" ;;
  esac
  sudo mkdir -p "$PIPER_DIR/voices"
  cd /tmp
  wget -q "https://github.com/rhasspy/piper/releases/latest/download/piper_linux_${PIPER_ARCH}.tar.gz" -O piper.tgz
  sudo tar -xzf piper.tgz -C "$PIPER_DIR" --strip-components=1
  sudo ln -sf "$PIPER_DIR/piper" /usr/local/bin/piper
  rm -f piper.tgz
  cd - >/dev/null
fi
ok "Piper installed"

# Voice model (Amy, female en_US, medium quality, ~60MB)
VOICE="$PIPER_DIR/voices/en_US-amy-medium.onnx"
if [ ! -f "$VOICE" ]; then
  log "Downloading Piper voice (Amy en_US medium)..."
  sudo wget -q -O "$VOICE" \
    "https://huggingface.co/rhasspy/piper-voices/resolve/main/en/en_US/amy/medium/en_US-amy-medium.onnx"
  sudo wget -q -O "${VOICE}.json" \
    "https://huggingface.co/rhasspy/piper-voices/resolve/main/en/en_US/amy/medium/en_US-amy-medium.onnx.json"
fi
ok "Piper voice: $VOICE"

# ─── 6. noVNC web root ────────────────────────────────────────────────────────
NOVNC_WEB=""
for p in /usr/share/novnc /usr/share/novnc-common; do
  [ -d "$p" ] && NOVNC_WEB="$p" && break
done
[ -n "$NOVNC_WEB" ] && ok "noVNC web root: $NOVNC_WEB" || warn "noVNC web root not detected"

# ─── 7. Sudoers for trainee user management ───────────────────────────────────
PLATFORM_USER="${SUDO_USER:-$USER}"
log "Configuring sudoers for $PLATFORM_USER..."
TMP_SUDO=$(mktemp)
cat > "$TMP_SUDO" <<EOF
# AI Training Platform — manage trainee users without password
$PLATFORM_USER ALL=(ALL) NOPASSWD: /usr/sbin/useradd, /usr/sbin/userdel, /usr/sbin/usermod, /usr/sbin/chpasswd, /usr/bin/pkill, /bin/pkill
$PLATFORM_USER ALL=(trainee0,trainee1,trainee2,trainee3,trainee4,trainee5,trainee6,trainee7,trainee8,trainee9) NOPASSWD: ALL
EOF

if sudo visudo -cf "$TMP_SUDO" >/dev/null 2>&1; then
  sudo install -m 0440 "$TMP_SUDO" /etc/sudoers.d/training-platform
  rm -f "$TMP_SUDO"
  ok "Sudoers installed at /etc/sudoers.d/training-platform"
else
  rm -f "$TMP_SUDO"
  fail "Sudoers validation failed — not installing"
fi

# ─── 8. systemd unit for whisper-server ───────────────────────────────────────
if [ -n "$WHISPER_SERVER" ]; then
  log "Installing whisper-server systemd unit..."
  sudo tee /etc/systemd/system/whisper-server.service >/dev/null <<EOF
[Unit]
Description=Whisper.cpp HTTP server (STT)
After=network.target

[Service]
Type=simple
User=$PLATFORM_USER
ExecStart=$WHISPER_SERVER -m $WHISPER_MODEL --port 8080 --host 127.0.0.1
Restart=on-failure
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF
  sudo systemctl daemon-reload
  sudo systemctl enable whisper-server
  sudo systemctl restart whisper-server
  sleep 2
  systemctl is-active --quiet whisper-server && ok "whisper-server running on :8080" \
    || warn "whisper-server inactive — check 'journalctl -u whisper-server'"
fi

# ─── Final verification ───────────────────────────────────────────────────────
echo
echo "═══════════════════════════════════════════════════"
echo "  Verification"
echo "═══════════════════════════════════════════════════"

OK=true
chk() { command -v "$1" >/dev/null && ok "$1" || { warn "$1 missing"; OK=false; }; }
chk Xvfb
chk x11vnc
chk websockify
chk startxfce4
chk node
chk ollama
chk piper

curl -sf http://localhost:11434/api/tags >/dev/null && ok "Ollama API on :11434" || { warn "Ollama not responding"; OK=false; }
curl -sf http://localhost:8080/ >/dev/null 2>&1 && ok "Whisper API on :8080" || warn "Whisper not responding (run: sudo systemctl start whisper-server)"

[ -n "$NOVNC_WEB" ] && [ -f "$NOVNC_WEB/vnc.html" ] && ok "noVNC vnc.html present" || warn "noVNC vnc.html missing"
[ -f "$VOICE" ] && ok "Piper voice file" || { warn "Piper voice missing"; OK=false; }
ollama list 2>/dev/null | grep -q gemma4 && ok "Gemma 4 model pulled" || warn "Gemma 4 not pulled — run: ollama pull $GEMMA_MODEL"

echo
if $OK; then
  echo -e "${GREEN}═══════════════════════════════════════════════════${NC}"
  echo -e "${GREEN}  ✅ Setup complete!${NC}"
  echo -e "${GREEN}═══════════════════════════════════════════════════${NC}"
  echo
  echo "Next steps:"
  echo "  cd $(pwd)"
  echo "  cp .env.example .env"
  echo "  npm install"
  echo "  ./scripts/start.sh"
  echo
  IP=$(hostname -I | awk '{print $1}')
  echo "Then open http://${IP}:3000 in your browser"
else
  echo -e "${YELLOW}═══════════════════════════════════════════════════${NC}"
  echo -e "${YELLOW}  ⚠ Setup completed with warnings${NC}"
  echo -e "${YELLOW}═══════════════════════════════════════════════════${NC}"
  echo "Review warnings above and address before running the platform."
fi
