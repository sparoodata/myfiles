#!/bin/bash
# Stop the AI Training Platform and clean up all sessions.

GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'; NC='\033[0m'
log()  { echo -e "${BLUE}▸${NC} $1"; }
ok()   { echo -e "${GREEN}✓${NC} $1"; }
warn() { echo -e "${YELLOW}⚠${NC} $1"; }

log "Stopping platform server..."
pkill -f "node server/index.js" 2>/dev/null && ok "Platform stopped" || warn "Platform was not running"

log "Killing any lingering trainee session processes..."
for u in trainee0 trainee1 trainee2 trainee3 trainee4 trainee5 trainee6 trainee7 trainee8 trainee9; do
  if id "$u" >/dev/null 2>&1; then
    sudo pkill -KILL -u "$u" 2>/dev/null || true
  fi
done
ok "Trainee processes cleaned"

log "Killing any orphan Xvfb / x11vnc / websockify processes..."
pkill -f "Xvfb :1[0-9]" 2>/dev/null || true
pkill -f "x11vnc.*-rfbport 591[0-9]" 2>/dev/null || true
pkill -f "websockify.*608[0-9]" 2>/dev/null || true
ok "Orphan processes cleaned"

read -p "Also stop whisper-server and Ollama? [y/N] " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
  sudo systemctl stop whisper-server 2>/dev/null || pkill -f whisper-server 2>/dev/null || true
  sudo systemctl stop ollama 2>/dev/null || pkill -f "ollama serve" 2>/dev/null || true
  ok "Backend services stopped"
fi

ok "All done."
