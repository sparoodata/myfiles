#!/bin/bash
# Start the AI Training Platform and all required services.
set -e

GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'; RED='\033[0;31m'; NC='\033[0m'
log()  { echo -e "${BLUE}▸${NC} $1"; }
ok()   { echo -e "${GREEN}✓${NC} $1"; }
warn() { echo -e "${YELLOW}⚠${NC} $1"; }
fail() { echo -e "${RED}✗${NC} $1"; exit 1; }

cd "$(dirname "$0")/.."  # cd to project root

# ─── Check .env ──
[ -f .env ] || { cp .env.example .env && warn ".env didn't exist, copied from .env.example — review it!"; }

# ─── 1. Ollama ──
log "Checking Ollama..."
if curl -sf http://localhost:11434/api/tags >/dev/null 2>&1; then
  ok "Ollama already running"
else
  log "Starting Ollama..."
  sudo systemctl start ollama 2>/dev/null || nohup ollama serve >/tmp/ollama.log 2>&1 &
  for i in {1..10}; do
    curl -sf http://localhost:11434/api/tags >/dev/null 2>&1 && break
    sleep 1
  done
  curl -sf http://localhost:11434/api/tags >/dev/null && ok "Ollama running" || fail "Ollama did not start"
fi

# ─── 2. Whisper server ──
log "Checking whisper-server..."
if curl -sf http://localhost:8080 >/dev/null 2>&1 || systemctl is-active --quiet whisper-server 2>/dev/null; then
  ok "whisper-server already running"
else
  log "Starting whisper-server..."
  if systemctl list-unit-files | grep -q whisper-server; then
    sudo systemctl start whisper-server
    sleep 2
    systemctl is-active --quiet whisper-server && ok "whisper-server running" \
      || warn "whisper-server systemd unit failed — check 'journalctl -u whisper-server'"
  else
    # Fallback: start manually
    WHISPER_BIN=""
    for p in /opt/whisper.cpp/build/bin/whisper-server /opt/whisper.cpp/build/bin/server /opt/whisper.cpp/server; do
      [ -x "$p" ] && WHISPER_BIN="$p" && break
    done
    [ -z "$WHISPER_BIN" ] && fail "whisper-server binary not found. Run scripts/setup-host.sh first"
    nohup "$WHISPER_BIN" -m /opt/whisper.cpp/models/ggml-base.en.bin --port 8080 --host 127.0.0.1 >/tmp/whisper.log 2>&1 &
    sleep 2
    ok "whisper-server started (logs: /tmp/whisper.log)"
  fi
fi

# ─── 3. Node deps ──
[ -d node_modules ] || { log "Installing npm packages..."; npm install --silent; }
ok "Node dependencies ready"

# ─── 4. Start the platform ──
echo
echo "═══════════════════════════════════════════════════"
echo "  Starting AI Training Platform"
echo "═══════════════════════════════════════════════════"
exec node server/index.js
