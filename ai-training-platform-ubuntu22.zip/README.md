# 🎓 AI Training Platform

A **multi-user, voice-driven, browser-native AI training platform**. Each student gets their own Ubuntu desktop session in the browser. An AI instructor (Gemma 4) plans and delivers the entire training on the fly — speaking, demoing, answering questions through voice.

## What it does

- Student types or speaks a topic → "Teach me Docker basics"
- Backend creates a fresh Linux user, virtual display, XFCE desktop
- AI instructor generates a 5-section lesson plan
- Student sees their Ubuntu desktop **live in the browser** (via noVNC)
- AI **speaks** the lesson, **runs commands** on the desktop, **opens browsers**, **writes files**
- Student can **interrupt with voice** — AI pauses, answers, resumes
- Multiple students can run simultaneous, independent sessions

## Architecture

```
Browser ─── HTTP/WS ──→ Orchestrator (Node.js)
                            │
                            ├─ creates → Linux user (trainee0...9)
                            ├─ spawns  → Xvfb (:10..:19)
                            ├─ spawns  → XFCE desktop session
                            ├─ spawns  → x11vnc (5910..5919)
                            └─ spawns  → noVNC bridge (6080..6089)

Per-session voice loop:
  Mic → WS → Whisper.cpp → Gemma 4 → Piper TTS → WS → Speakers
```

## Setup

### Hardware

| Concurrent students | Recommended host |
|---|---|
| 1-3 | 16GB RAM, modern CPU |
| 5-10 | 32GB RAM + small GPU (RTX 3060) |
| 10-30 | 64GB RAM + RTX 4090 / A6000 |

### One-shot installation

```bash
# On a fresh Ubuntu 22.04 host
git clone <this-repo> training-platform
cd training-platform
chmod +x scripts/setup-host.sh
./scripts/setup-host.sh
```

This installs: Xvfb, XFCE, x11vnc, noVNC, Node.js 20, Ollama, Gemma 4 E4B, whisper.cpp + base.en model, Piper TTS + Amy voice.

### Manual configuration

```bash
cp .env.example .env
# edit .env — pick your Gemma model, adjust ports if needed
npm install
```

### Running

```bash
# 3 services need to be running:

# Terminal 1: Ollama
ollama serve

# Terminal 2: Whisper.cpp HTTP server
/opt/whisper.cpp/build/bin/whisper-server \
  -m /opt/whisper.cpp/models/ggml-base.en.bin \
  --port 8080

# Terminal 3: The platform
node server/index.js
```

Open `http://your-host:3000` in any modern browser.

## How a session works

1. **Student opens the URL**, sees a topic input
2. **Types "Docker basics"** and hits Start
3. Backend:
   - Picks the next free slot (e.g. slot 0 → user `trainee0`, display `:10`)
   - Ensures the Linux user exists, creates it if not
   - Starts Xvfb on `:10` with screen `1280x800x24`
   - Starts XFCE desktop on that display
   - Starts x11vnc bridging the X display to VNC port `5910`
   - Starts noVNC bridge on port `6080` so the browser can connect
   - Returns the session info to the browser
4. **Browser loads noVNC iframe** showing the live desktop
5. **Voice WebSocket connects** at `/voice/{sessionId}`
6. **Instructor agent activates**:
   - Calls Gemma 4 with the topic → gets a structured lesson plan JSON
   - Speaks the intro through Piper TTS
   - For each section: speak narration → run demo steps in the desktop → speak summary
7. **Student taps the mic** at any time, asks a question
8. Audio streams to backend → Whisper transcribes → Agent pauses → Gemma answers → Piper speaks → Agent resumes the lesson

## Key files

```
server/
  index.js              — main server, REST + WS + noVNC proxy
  session-manager.js    — Linux user/display/VNC lifecycle
  voice-pipeline.js     — Whisper, Gemma, Piper integration
  instructor-agent.js   — Lesson planning, demo execution, voice Q&A
public/
  index.html            — single-page browser UI (voice + noVNC view)
scripts/
  setup-host.sh         — one-shot installer for all OS dependencies
```

## Customization

### Different TTS voice
Set `PIPER_VOICE` in `.env`. Browse voices at [rhasspy/piper-voices](https://huggingface.co/rhasspy/piper-voices).

### Different Gemma size
Set `OLLAMA_MODEL=gemma4:31b` (or `e2b`/`e4b`/`26b`). Pull it first with `ollama pull <model>`.

### Different language
- Pull a multilingual Whisper model: `bash /opt/whisper.cpp/models/download-ggml-model.sh medium`
- Pick a Piper voice in your language
- Gemma 4 supports 140+ languages out of the box

## Security notes

This platform creates and destroys Linux users dynamically. The orchestrator needs `sudo` access to:
- `useradd`, `userdel`, `usermod`, `chpasswd`
- Run commands as `trainee0..9`
- `pkill` to clean up sessions

The setup script writes a `/etc/sudoers.d/training-platform` file with these grants. **Run only on hosts you control.** Don't expose port 3000 directly to the internet — put it behind nginx with auth.

## Known limitations (MVP)

- **No isolation** between sessions on the same host (one trainee can theoretically see another's processes via `ps`). For multi-tenant production, swap user-mode for LXD containers — the orchestrator design supports this with minimal changes.
- **Audio playback in browser** uses the simple `<audio>` element. For lower latency, switch to MediaSource Extensions or WebRTC.
- **VAD (voice activity detection)** is a basic timeout. For production, use a proper VAD library like Silero VAD on the backend.
- **First TTS chunk has ~300ms latency** with Piper. For real-time conversation feel, switch to streaming TTS (e.g. Coqui XTTS streaming).

## Roadmap

- [ ] Replace user-mode sessions with LXD containers for proper isolation
- [ ] Streaming TTS for lower-latency speech
- [ ] Save/replay sessions (record VNC + audio + transcript)
- [ ] Admin dashboard to manage sessions
- [ ] Pre-built course catalog with custom slide decks
- [ ] Multi-language UI
